package com.globant.data.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Setter
@AllArgsConstructor
@Slf4j
public class Restaurant {

    private String name;
    private Menu menu;

    public void printDetails() {
        log.info("Welcome to : {} ", name);
        for (Recipe recipe : menu.getRecipes()) {
            log.info(" * {} = {} ", recipe.getName(), recipe.getPrice());
        }
    }

}
