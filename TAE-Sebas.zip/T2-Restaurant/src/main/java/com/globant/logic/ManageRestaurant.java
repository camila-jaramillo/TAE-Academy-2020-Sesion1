package com.globant.logic;

import com.globant.data.entities.Menu;
import com.globant.data.entities.Recipe;
import com.globant.data.entities.Restaurant;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@Slf4j
public class ManageRestaurant {

    private static final String NAME_RESTAURANT = "Sebastian's Restaurant";

    public static void main(String[] args) {

        Restaurant restaurant = new Restaurant(NAME_RESTAURANT, new Menu(null));
        restaurant.getMenu().setRecipes(addRecipes());
        putVeganRecipe(restaurant, new Recipe("Apple and Banana", 6.00), 3);
        log.info("The amount of recipes are : {} \n", restaurant.getMenu().getRecipes().size());
        restaurant.printDetails();
    }

    private static List<Recipe> addRecipes() {
        log.info("Adding recipes");
        List<Recipe> recipes = new ArrayList<Recipe>();
        recipes.add(new Recipe("Sushi", 9.99));
        recipes.add(new Recipe("Chicken", 15.99));
        recipes.add(new Recipe("Meat", 18.99));
        recipes.add(new Recipe("Salad", 5.99));
        recipes.add(new Recipe("Cake", 7.50));
        log.info("The recipes are : {} ", recipes.toString());
        return recipes;
    }

    private static void putVeganRecipe(Restaurant restaurant, Recipe recipe, int index){
        log.info("Replacing option : {} to a vegan recipe : {}", index, recipe.toString());
        restaurant.getMenu().getRecipes().set(index-1, recipe);
    }

}
