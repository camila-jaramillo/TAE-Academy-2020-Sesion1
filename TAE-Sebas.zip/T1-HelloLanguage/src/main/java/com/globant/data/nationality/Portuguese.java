package com.globant.data.nationality;

import com.globant.data.entities.Person;

public class Portuguese extends Person {
    public Portuguese(String firstName, String lastName) {
        super(firstName, lastName);
    }

    @Override
    public String sayHello() {
        return "Alô!";
    }
}
