package com.globant.data.entities;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public abstract class Person {

    private String firstName;
    private String lastName;

    public String response() {
        return "My name is " + firstName + " " + lastName + ". " + sayHello();
    }

    public abstract String sayHello();

}
