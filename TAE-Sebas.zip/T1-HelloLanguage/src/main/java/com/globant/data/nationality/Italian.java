package com.globant.data.nationality;

import com.globant.data.entities.Person;

public class Italian extends Person {
    public Italian(String firstName, String lastName) {
        super(firstName, lastName);
    }

    @Override
    public String sayHello() {
        return "Ciao!";
    }
}
