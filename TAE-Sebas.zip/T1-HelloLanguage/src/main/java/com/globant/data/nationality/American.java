package com.globant.data.nationality;

import com.globant.data.entities.Person;

public class American extends Person {
    public American(String firstName, String lastName) {
        super(firstName, lastName);
    }

    @Override
    public String sayHello() {
        return "Hello!";
    }
}
