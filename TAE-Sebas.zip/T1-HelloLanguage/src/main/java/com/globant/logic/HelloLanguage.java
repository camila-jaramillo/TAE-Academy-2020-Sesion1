package com.globant.logic;

import com.globant.data.entities.Person;
import com.globant.data.nationality.*;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@Slf4j
public class HelloLanguage {

    public static void main(String[] args) {
        List<Person> people = createList();
        for (Person person : people) log.info(" -> {} ", person.response());
    }

    private static List<Person> createList() {
        List<Person> people = new ArrayList();
        people.add(new American("Richad", "Smith"));
        people.add(new Spanish("Sebastian", "Mesa"));
        people.add(new Italian("Mario", "Bross"));
        people.add(new French("Linguini", "Paris"));
        people.add(new Portuguese("Cristiano", "Ronaldo"));
        return people;
    }

}
