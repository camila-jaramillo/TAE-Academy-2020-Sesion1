package restaurant;

/**
 * @author Mar�a Camila Jaramillo Benavides
 * Quality Control
 */
public class Recipie {
	
	private String name; 
	private String recipie; 
	private String price;

	public Recipie(String name,String recepie,String price) {
		this.name = name; 
		this.recipie = recepie;
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRecipie() {
		return recipie;
	}

	public void setRecipie(String recipie) {
		this.recipie = recipie;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	
	public void addRecipie() {
		
		
	}
	
}
