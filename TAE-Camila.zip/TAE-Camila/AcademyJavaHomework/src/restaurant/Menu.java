package restaurant;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mar�a Camila Jaramillo Benavides
 * Quality Control
 */
public class Menu {
	
	private List<Recipie> recipie = new ArrayList<Recipie>(); 
	
	public Menu(List<Recipie> recipie) {
		this.recipie = recipie;
	}

	public List<Recipie> getRecipie() {
		return recipie;
	}

	public void setRecipie(List<Recipie> recipie) {
		this.recipie = recipie;
	}
	
}
