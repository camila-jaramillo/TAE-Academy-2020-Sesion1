package test;

import utils.Utils;

import java.util.ArrayList;
import java.util.List;

import restaurant.Menu;
import restaurant.Recipie;
import restaurant.Restaurant;

public class Test {

	public static void main(String[] args) {
		
		Utils utils = new Utils();
		List<Recipie> list = new ArrayList<Recipie>(); 
		
		list = utils.listOfRecipies(list);
		Menu menu = new Menu(list);
		Restaurant restaurant = new Restaurant("A la Colombiana",menu);
		
		
		utils.PrintRecipies(restaurant);
		
		Recipie vegan = new Recipie("Quinua con frijol","Quinua,frijol","8000");
		list.add(2,vegan);
		list.remove(3);
		menu.setRecipie(list);
		
		utils.amountOfRecipies(restaurant);
		utils.PrintRecipies(restaurant);
		
	}

}
