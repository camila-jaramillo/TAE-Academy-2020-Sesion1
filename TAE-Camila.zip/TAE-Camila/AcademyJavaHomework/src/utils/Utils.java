package utils;

import java.util.List;
import java.util.Scanner;

import restaurant.Menu;
import restaurant.Recipie;
import restaurant.Restaurant;

/**
 * @author Mar�a Camila Jaramillo Benavides
 * Quality Control
 */
public class Utils {
	
	public Utils(){
		
	}

	/**This Method creates a list of the type Recipie receiving them by console
	 * @param listOfRecipie Empty list of recipies 
	 * @return listOfRecipie List of recipies added by the user
	 */
	public List<Recipie> listOfRecipies(List<Recipie> listOfRecipie){
		 
		Recipie recipieAux;
		
		try (Scanner scaner = new Scanner(System.in)) {
			for(int i=0; i<5; i++){
				System.out.println("Please write the name for the menu option:");
				String name = scaner.nextLine();
				System.out.println("Please write the recipie for the menu option:");
				String recipie = scaner.nextLine();
				System.out.println("Please write the price for the recipie:");
				String price = scaner.nextLine();;
				recipieAux = new Recipie(name,recipie,price);
				listOfRecipie.add(recipieAux);
			}
			
			return listOfRecipie;
		}
	}
	
	/**Method that prints the recipies in a menu of a restaurant
	 * @param restaurant receives as a Parameter an object of type Restaurant that has the menu and the recipies
	 */
	public void PrintRecipies(Restaurant restaurant){
		
		Menu menu = restaurant.getMenu();
		List<Recipie> listOfRecipie = menu.getRecipie();
		
		System.out.println("-------------------------"+restaurant.getName()+"------------------------");
		System.out.println("------------------WELCOME TO OUR MENU --------------------------");	
		System.out.println("----------------------------------------------------------------");
		System.out.println("Name                           Recipie                Price   ");
		for(Recipie recipie : listOfRecipie){
			System.out.println(recipie.getName()+"             "+recipie.getRecipie()+"                "+recipie.getPrice());
		}
		System.out.println("");
	}
	
	/**This method prints the number of recipies in a menu of a restaurant
	 * @param restaurant receives as a Parameter an object of type Restaurant that has the menu and the recipies
	 */
	public void amountOfRecipies(Restaurant restaurant){
		Menu menu = restaurant.getMenu();
		List<Recipie> recipies = menu.getRecipie();
		System.out.println("The amount of recipies we have in our menu are: "+recipies.size());
		System.out.println("");
	}
}
