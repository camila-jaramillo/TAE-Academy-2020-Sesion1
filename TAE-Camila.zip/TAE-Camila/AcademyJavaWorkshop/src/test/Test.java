package test;

import java.util.List;

import nationalities.People;
import nationalities.Person;

/**
 * @author Mar�a Camila Jaramillo Benavides
 * Quality Control
 */
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		People people = new People();
		List<Person> person = people.addListPeople();
		people.printPeople(person);
		
	}

}
