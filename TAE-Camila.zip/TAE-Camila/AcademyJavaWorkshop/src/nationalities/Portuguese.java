package nationalities;

public class Portuguese extends Person {

	public Portuguese(String fullName, String greetings) {
		super(fullName, greetings);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void sayHi() {
		// TODO Auto-generated method stub
		System.out.println( "Meu nome e: "+this.getFullName()+", "+this.getGreetings());
	}

}
