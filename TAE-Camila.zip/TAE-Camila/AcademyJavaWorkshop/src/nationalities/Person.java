package nationalities;

/**
 * @author Mar�a Camila Jaramillo Benavides
 * Quality Control
 */
public abstract class Person {

	protected String fullName;
	protected String greetings;

	/**Constructor for the class Person
	 * @param fullName name of the person
	 * @param greetings how the nationality greet
	 */
	public Person(String fullName, String greetings){
		this.fullName = fullName;
		this.greetings = greetings;
	}
	
	public Person(){
		
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getGreetings() {
		return greetings;
	}

	public void setGreetings(String greetings) {
		this.greetings = greetings;
	}

	/**Abstract Method that prints depending of the nationality the name and the greeting in
	 * their respective language
	 * 
	 */
	protected abstract void sayHi();

}
