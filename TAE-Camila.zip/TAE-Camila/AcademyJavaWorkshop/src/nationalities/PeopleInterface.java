package nationalities;

import java.util.List;

/**
 * @author Mar�a Camila Jaramillo Benavides
 * Quality Control
 */
public interface PeopleInterface {

	
	/**The method addListPeople creates a list of type Person and returns it
	 * @return The list Person
	 */
	public List<Person> addListPeople();
	
	
	/**The method calls the abstract method sayHi()
	 * @param Receives as a parameter a list of people
	 */
	public void printPeople(List<Person> person);
}
