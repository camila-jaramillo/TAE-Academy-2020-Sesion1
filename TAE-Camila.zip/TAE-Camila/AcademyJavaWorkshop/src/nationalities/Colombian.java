package nationalities;

/**
 * @author Mar�a Camila Jaramillo Benavides
 * Quality Control
 */
public class Colombian extends Person{

	public Colombian(String fullName, String greetings) {
		super(fullName, greetings);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void sayHi() {
		// TODO Auto-generated method stub
		System.out.println("Mi nombre es: "+this.getFullName()+", "+this.getGreetings());
	}

}
