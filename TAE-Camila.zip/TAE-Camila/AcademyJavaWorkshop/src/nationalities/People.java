package nationalities;

import java.util.ArrayList;
import java.util.List;

public class People implements PeopleInterface {

	/**
	 * @author Mar�a Camila Jaramillo Benavides
	 * Quality Control
	 */
	public People() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Person> addListPeople() {
		Person colombian = new Colombian("Maria Camila","!Hola!");
		Person french = new French("Pierre","�Bonjour!");
		Person italian = new Italian("Pietro","�Ciao!");
		Person english = new English("Samantha","�Hello!");
		Person portuguese = new Portuguese("Ronaldo","�Ola!");
		List<Person> people = new ArrayList<Person>();
		people.add(colombian);
		people.add(french);
		people.add(italian);
		people.add(english);
		people.add(portuguese);
		
		return people;
	}

	@Override
	public void printPeople(List<Person> person){
		for(Person aux: person) {
			aux.sayHi();
		}
	}


}