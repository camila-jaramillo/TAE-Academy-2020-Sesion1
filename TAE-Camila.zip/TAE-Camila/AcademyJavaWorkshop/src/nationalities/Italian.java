package nationalities;

/**
 * @author Mar�a Camila Jaramillo Benavides
 * Quality Control
 */
public class Italian extends Person {

	public Italian(String fullName, String greetings) {
		super(fullName, greetings);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void sayHi() {
		// TODO Auto-generated method stub
		System.out.println( "Mi chiamo: "+this.getFullName()+", "+this.getGreetings());
	}

}
